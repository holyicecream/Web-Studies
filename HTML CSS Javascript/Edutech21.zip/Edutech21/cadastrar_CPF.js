function cadastrarProduto(){
  alert("CPF do professor cadastrado com sucesso!")

  window.location.href='cadastro.html'
}
