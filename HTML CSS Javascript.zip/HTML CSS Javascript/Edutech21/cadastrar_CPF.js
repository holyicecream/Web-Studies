function cadastrarProduto(){
  var nome  = document.getElementById("nome");
  var CPF  = document.getElementById("CPF");
  var escolas  = document.getElementById("escolas");

  var dados = JSON.parse(localStorage.getItem("dadosCadastro"));
  
  if (dados == null){
    localStorage.setItem("dadosCadastro", "[]");
    dados = [];
  }

  
  var auxRegistro = {
    nomes: nome.value,
    cpfs: CPF.value,
    escola: escolas.value
    
  }

  dados.push(auxRegistro);

  localStorage.setItem("dadosCadastro", JSON.stringify(dados));
  alert("CPF do professor cadastrado com sucesso!")

  nome.value = "";
  CPF.value = "";
  escolas.value = "";

  let list = document.getElementById("dadosCadastro");
 
dados.forEach((item)=>{
  let li = document.createElement("li");
  li.innerText = item;
  list.appendChild(li);
})
   
}

/*const formulario = document.querySelector("form");
const ulNomes = document.querySelector("ul");

formulario.addEventListener("submit", function (e){
  e.preventDefault();
  let novaPessoa = new Object();
  novaPessoa.nome = this.nome.value;
  novaPessoa.CPF = this.nome.value;
  novaPessoa.escolas = this.escolas.value;
  console.log(novaPessoa);
})*/
