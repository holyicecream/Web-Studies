










function agendarAula() {
    // Get values from form inputs
    var titulo = document.getElementById("titulo").value;
    var turma = document.getElementById("turma").value;
    var data = document.getElementById("data").value;
    var materia = document.getElementById("materia").value;
    var desc = document.getElementById("desc").value;
    var senha = document.getElementById("senha").value;
  
    // Add the new event to the table
    var table = document.getElementById("aulas");
    var row = table.insertRow();
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    cell1.innerHTML = titulo;
    cell2.innerHTML = turma;
    cell3.innerHTML = data;
    cell4.innerHTML = materia;
    cell5.innerHTML = desc;
    cell6.innerHTML = senha;

    console.log("funcionou");
  }
  
function agendarAula(){
    var titulo  = document.getElementById("titulo");
    var turma  = document.getElementById("turma");
    var data  = document.getElementById("data");
    var materia  = document.getElementById("materia");
    var desc  = document.getElementById("desc");
    var senha  = document.getElementById("senha");

    var dados = JSON.parse(localStorage.getItem("dadosAula"));
    
    if (dados == null){
      localStorage.setItem("dadosAula", "[]");
      dados = [];
    }
  
    
    var auxRegistro = {
      Titulo: titulo.value,
      Turma: turma.value,
      Data: data.value,
      Materia: materia.value,
      Desc: desc.value,
      Senha: senha.value
      
    }
  
    dados.push(auxRegistro);
  
    localStorage.setItem("dadosAula", JSON.stringify(dados));
    alert("Aula agendada com sucesso!")
  
    titulo.value = "";
    turma.value = "";
    data.value = "";
    materia.value = "";
    desc.value = "";
    senha.value = "";
  
    let list = document.getElementById("dadosAula");
   
  dados.forEach((item)=>{
    let li = document.createElement("li");
    li.innerText = item;
    list.appendChild(li);
  })
     
}
btnAgendar.addEventListener("click", agendarAula)